import React, { useEffect } from "react";
import LoginForm from "./components/LoginForm";
import MessagesList from "./components/MessageList";
import { UserList } from "./components/UsersList";
import { getAccessToken } from "./utils";
import * as jwt from 'jsonwebtoken'
import { useDispatch, useSelector } from "react-redux";
import { userToStore } from "./actions/Users";
import { IRootState } from "./reducers";
import { IUsersInitialState } from "./reducers/Users";



function App() {
  const { user } = useSelector<IRootState, IUsersInitialState>(state => state.users)
  const dispatch = useDispatch()
  useEffect(() => {
    const token = getAccessToken();
    if (token) {
      const user = jwt.decode(token)
      dispatch(userToStore(user))
    }
  }, [user])
  return (
    <div className="App" >
      <LoginForm />
      <MessagesList />
      <UserList />
    </div>
  );
}

export default App;
