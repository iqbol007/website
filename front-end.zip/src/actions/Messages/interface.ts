export const MessageActions = {
    CREATE_MESSAGE: 'CREATE_MESSAGE',
    GET_ALL_MESSAGES: 'GET_ALL_MESSAGES',
    GET_MESSAGE_BY_ID: 'GET_MESSAGE_BY_ID',
    REMOVE_MESSAGE: 'REMOVE_MESSAGE',
    EDIT_MESSAGE: 'EDIT_MESSAGE',
};
export interface IMessageSent {

}
export interface IMessageEdit {

}
export interface IMessageRemove {

}
export interface IMessageIncome {

}