import { IUser } from "../../actions/Users/interfaces";

export interface IUserList {
    users: IUser[] | null
}